# code-next-emoji-search-zajvg2

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/code-next-emoji-search-zajvg2)